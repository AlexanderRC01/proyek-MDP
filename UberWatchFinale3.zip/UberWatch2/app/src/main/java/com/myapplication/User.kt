package com.myapplication

data class User(
    val uid: String = "",
    val name: String = "",
    val emailAddress: String = "",
    val role: String = ""
)
