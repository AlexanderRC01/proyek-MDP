package com.myapplication

class ModeratorAdapter {

}
