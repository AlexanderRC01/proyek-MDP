package com.myapplication

class Glide {

}
